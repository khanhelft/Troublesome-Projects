﻿create database QLTS
use QLTS
create table người
(
	ID varchar(20),
	CMND char(10),
	Tên nvarchar(30),
	Giới_tính BIT ,
	Nơi_Sinh nvarchar(20)
	primary key(ID)
)
create table Thí_Sinh
(
	MaTS varchar(20),
	Địa_chỉ nvarchar(30),
	Điện_thoại varchar(20),
	Giới_thiệu text
	primary key(MaTS)
)

create table Nghệ_Sỹ
(
	MaNS varchar(20),
	Nghệ_danh char(10),
	Thành_tích text ,
	MCflag BIT,
	CSflag BIT,
	NSflat BIT
	primary key(MaNS)
)

create table Chương_Trình_MC_dẫn
(
	MaMC varchar(20) ,
	Chương_Trình_đã_dẫn text
	primary key(MaMC)
)

create table Album_ca_sỹ
(
	MaCS varchar(20) ,
	album char(50)
	primary key (MaCS)
)

create table Bài_hát
(
	MaBH varchar(20),
	Tựa_bài_hát nvarchar(20) not null
	primary key(MaBH)
)
create table Thể_loại
(
	MaTL varchar(20),
	Tên_Thể_loai nvarchar(20) not null
	primary key(MaTL)

)
create table Bài_hát_thuộc_thể_loại
(
	MaBH varchar(20),
	MaTL varchar(20)
	primary key(MaBH , MaTL)
)

create table Nhạc_sỹ_sáng_tác
(
	MaNhS varchar(20) ,
	MaBH varchar(20) ,
	Thông_tin_sáng_tác nvarchar(30) check(Thông_tin_sáng_tác like N'sáng tác phần lời' or Thông_tin_sáng_tác like'sáng tác phần nhạc' or Thông_tin_sáng_tác like 'cả hai (nhạc và lời)' )
	primary key(MaNhs , MaBH)
)
create table Tỉnh_thành
(
	MaTT varchar(20) ,
	Tên_tỉnh_thành nvarchar(10) not null
	primary key(MaTT)
)
create table Nhà_sản_xuất
(
	Mansx varchar(20),
	Tên_Nhà_sản_xuất nvarchar(20) 
	primary key(Mansx) 
)
create table Kênh_truyền_hình
(
	Mak varchar(20),
	Tên_kênh nvarchar(20) not null
	primary key(Mak)
)
create table Mùa_thi
(
	Mamt varchar(20),
	NgaythangBD date,
	NgayThangKT date,
	Giải_thưởng text,
	Địa_điểmvongnhahat nvarchar(20),
	Địa_điểmvongbanket nvarchar(20),
	Địa_điểmvonggala nvarchar(20),
	MaGDAM varchar(20),
	MaGD1 varchar(20),
	MaGD2 varchar(20),
	MaGD3 varchar(20),
	MaMC varchar(20)
	primary key(Mamt)
)
create table Giữ_bản_quyền_mua_thi
(
	Mamt varchar(20),
	Mansx varchar(20),
	primary key(Mamt , Mansx)
)
create table Phát_sóng
(
	Mamt varchar(20),
	Mak varchar(20),
	Thông_tin_phát_sóng nvarchar(20) check(Thông_tin_phát_sóng like 'chỉ phát sóng vòng bán kết' or Thông_tin_phát_sóng like ' chỉ phát sóng vòng gala' or Thông_tin_phát_sóng like 'phát sóng cả hai vòng' )
)

alter table Thí_Sinh add constraint FK_TS_Nguoi foreign key(MaTS) references Người(ID)
alter table Nghệ_Sỹ add constraint FK_NS_nguoi foreign key(MaNS) references Người(ID)
alter table Chương_Trình_MC_dẫn add constraint FK_CTMCD_NS foreign key(MaMC) references Nghệ_Sỹ(MaNS)
alter table Album_ca_sỹ add constraint FK_ACS_NS foreign key(MaCS) references Nghệ_Sỹ(MaNS)
alter table Bài_hát_thuộc_thể_loại add constraint FK_BHTTL_BH foreign key(MaBH) references Bài_hát(MaBH)
alter table Bài_hát_thuộc_thể_loại add constraint FK_BHTTL_TL foreign key(MaTL) references Thể_loại(MaTL)
alter table Nhạc_sỹ_sáng_tác add constraint FK_NSST_NS foreign key(MaNhs) references Nghệ_sỹ(MaNS)
alter table Nhạc_sỹ_sáng_tác add constraint FK_NSST_BH foreign key(MaBH) references Bài_hát(MaBH)
alter table Giữ_bản_quyền_mua_thi add constraint FK_GBQMT_MT foreign key(Mamt) references Mùa_thi(Mamt)
alter table Giữ_bản_quyền_mua_thi add constraint FK_GBQMT_NSX foreign key(Mansx) references Nhà_sản_xuất(Mansx)
alter table Phát_sóng add constraint FK_PS_MT foreign key(Mamt) references Mùa_thi(Mamt)
alter table Phát_sóng add constraint FK_PS_KTH foreign key(MaK) references Kênh_truyền_hình(Mak)
